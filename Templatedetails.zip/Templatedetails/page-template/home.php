<?php
/*Template Name: Home Page*/
get_header();
?>
   <section class="index banner bnr_area" style="background: url(<?php the_field('home_banner_image')?>) no-repeat;">
      <div class="bnr_hd wow pulse">
         <h5><?php the_field('home_banner_sub_title'); ?></h5>
         <h1><?php the_field('home_banner_title'); ?></h1>
         <p><?php the_field('home_banner_content'); ?></p>
         <div class="bnr-btn">
            <ul>
               <li><a href="<?php the_field('home_banner_cta1_link'); ?>" class="cmn_btn  bn-btn"><?php the_field('home_banner_cta1_text'); ?></a></li>
               <li><a href="<?php the_field('home_banner_cta2_link'); ?>" class="cmn_btn  bn-btn"><?php the_field('home_banner_cta2_text'); ?></a></li>
            </ul>
         </div>
      </div>
   </section>

   <?php //echo do_shortcode( '[ti_wishlistsview]' ); ?>

   <section class="sale_sec">
      <div class="container-wci">
         <div class="cmn_hdr text-center wow fadeInDown">
            <h2><?php the_field('products_section_title'); ?></h2>
            <p><?php the_field('products_section_content'); ?></p>
         </div>
         <div class="sale_otr">
            <div id="home" class="tab-pane fade in active show">
               <div class="sales_innr slider_cmn_arw">
               <?php 
                  global $post;
                  $post_id=$post->ID;
                  $product = wc_get_product( $post_id ); 

                  $args = array( 'post_type' => 'product', 'product_cat' => '', 'posts_per_page' =>6, 'order' => 'DESC' );
                  $loop = new WP_Query( $args );
                  while ( $loop->have_posts() ) : $loop->the_post();
                  $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($loop->ID),'full');
               ?> 
                  <div class="sales_box">
                     <div class="sales_bx_innr">
                        <div class="like_img"><?php echo do_shortcode( '[ti_wishlists_addtowishlist loop=yes]' ); ?></div>
                        <div class="sales_prd">
                           <img src="<?php echo $thumb[0];?>" alt="<?php echo $post_id; ?>" />
                        </div>
                        <div class="sales_con">
                           <h3><?php the_title(); ?></h3>
                        </div>
                        <div class="add_crt">
                           <h4><del><?php echo get_woocommerce_currency_symbol(); ?> <?php echo $product->get_regular_price(); ?></del> – <?php echo get_woocommerce_currency_symbol(); ?> <?php echo $product->get_price(); ?></h4>
                           <a href="<?php the_permalink(); ?>" class="cmn_btn btn btn-primary ">Add To Cart</a>
                        </div>
                     </div>
                  </div>
               <?php endwhile;
               wp_reset_query(); ?>
               </div>
            </div>
         </div>
      </div>
   </section>

   <section class="about-k-sec">
      <div class="container-wci">
         <div class="row">
            <div class="col-md-7">
               <div class="abt-k-txt wow fadeInLeftBig" data-wow-delay="0.2s">
                  <div class="cmn_hdr text-left wow fadeInLeftBig">
                     <h2><?php the_field('about_section_title'); ?></h2>
                     <p><?php the_field('about_section_content'); ?></p>
                     <ul>
                        <li><a href="https://wa.me/<?php the_field('about_section_contact_no'); ?>" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i> <?php the_field('about_section_contact_no'); ?></a></li>
                        <li><a href="mailto:<?php the_field('about_section_email'); ?>"><i class="fa fa-envelope" aria-hidden="true"></i> <?php the_field('about_section_email'); ?></a></li>
                     </ul>
                     <a href="<?php the_field('about_section_cta_link'); ?>" class="yl-btn btn btn-primary"><?php the_field('about_section_cta_text'); ?></a>
                  </div>
               </div>
            </div>
            <div class="col-md-5 sm-pt">
               <div class="abt-k-pic wow fadeInRightBig" data-wow-delay="0.4s">
                  <div class="abt-pic-outr">
                     <div class="abt-outr-2">
                        <div class="abt-outr-3">
                           <div class="gt-gg">
                              <img src="<?php the_field('about_section_image'); ?>" alt="" />
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

   <section class="histqlty">
      <div class="container-wci">
         <div class="cmn_hdr text-center wow fadeInDown">
            <h2><?php the_field('why_web_cabinet_section_title'); ?></h2>
            <p><?php the_field('why_web_cabinet_section_content'); ?></p>
         </div>
         <div class="histqlty_otr">
            <div class="row">
            <?php 
            $i=0;
            while ( have_rows('why_web_cabinet_section_info') ) : the_row(); ?>
               <div class="col-md-4 wow fadeInLeftBig" data-wow-delay="0.<?php echo $i=$i+1; ?>s">
                  <div class="histqlty_box">
                     <div class="histqlty_pic_otr">
                        <div class="histqlty_pic">
                           <div class="histqlty_pic_innr">
                              <img src="<?php the_sub_field('services_icon');?>" alt="">
                           </div>
                        </div>
                     </div>
                     <div class="histqlty_txt_otr">
                        <h3><?php the_sub_field('services_title');?></h3>
                        <p><?php the_sub_field('services_content');?></p>
                     </div>
                  </div>
               </div>
            <?php endwhile;
            wp_reset_query(); ?>
            </div>
         </div>
      </div>
   </section>

   <section class="resrv-sec">
      <div class="resrv-outr">
         <div class="row">
            <div class="col-md-6 rev wow fadeInLeftBig" data-wow-delay="0.4s">
               <div class="resrv-pic img_scale">
                  <img src="<?php the_field('services_section_image'); ?>" alt="" />
               </div>
            </div>
            <div class="col-md-6 rev wow fadeInRightBig" data-wow-delay="0.6s">
               <div class="resrv-txt">
                  <div class="cmn_hdr text-left">
                     <h2><?php the_field('services_section_title'); ?></h2>
                     <p><strong><?php the_field('services_section_sub_title'); ?></strong></p>
                     <p><?php the_field('services_section_content'); ?></p>
                     
                     <a href="<?php the_field('services_section_cta_link'); ?>" class="yl-btn btn btn-primary"><?php the_field('services_section_cta_text'); ?></a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

   <section class="latest_blog">
      <div class="container-wci">
      <div class="cmn_hdr text-center wow fadeInDown">
         <h2><?php the_field('blog_section_title'); ?></h2>
         <p><?php the_field('blog_section_content'); ?></p>
      </div>
      
      <div class="le_blg_inr le_blg_otr slider_cmn_arw row">
      <?php $args = array( 'post_type' => 'post', 'posts_per_page' =>'4','order'=>'DESC','orderby'=>'date' );
		$query=new WP_Query($args); 
		$i=1;
		while ( $query->have_posts() ) : $query->the_post();
		$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($query->ID),'full');
		?>
         <div class="col-md-3">
            <div class="le_blg_box_innr wow fadeInRightBig" data-wow-delay="0.<?php echo $i=$i+1; ?>s">
               <div class="le_blg_img img_scale">
                  <img src="<?php echo $thumb[0];?>" alt="">
               </div>
               <div class="blg_con">
                  <ul>
                     <li><i class="fa fa-calendar-check-o" aria-hidden="true"></i>  | <?php echo get_the_date()?></li>
                  </ul>
                  <h4><?php echo wp_trim_words( get_the_title(), 10);?></h4>
                  <p><?php echo wp_trim_words( get_the_content(), 30);?></p>
                  
                  <a href="<?php echo get_permalink(); ?>">Read More</a>
               </div>
            </div>
         </div>
      <?php endwhile;
      wp_reset_query(); ?>
      </div>

      <div class="bk_rec_btn text-center wow pulse" data-wow-duration="1s" data-wow-delay="1.2s">
         <a href="<?php the_field('blog_section_cta_link'); ?>" class="cmn_btn btn btn-primary"><?php the_field('blog_section_cta_text'); ?></a>
      </div>
      </div>
   </section>

   <section class="test-sec" style="background: url('<?php the_field('testimonials_section_background_image'); ?>');">
      <div class="container-wci">
         <div class="cmn_hdr text-center wow fadeInDown">
            <h2><?php the_field('testimonials_section_title'); ?></h2>
            <p><?php the_field('testimonials_section_content'); ?></p>
         </div>
         <div class="test-otr">
            <div class="test-innr slider_cmn_arw wow fadeInRight" data-wow-delay="0.4s">
            <?php 
            $args = array( 'post_type' => 'testimonials_info', 'posts_per_page' =>'-1','order'=>'DESC','orderby'=>'date' );
            $query=new WP_Query($args);
            if ( $query->have_posts() ) {
               while ( $query->have_posts() ) : $query->the_post();
               $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($query->ID),'full');
            ?>
               <div class="test_box">
                  <div class="tst-in">
                     <p>“<?php echo wp_trim_words( get_the_content(), 45);?>”</p>
                  </div>
                  <div class="test-cmnt">
                     <div class="test-cmnt-img">
                        <img src="<?php echo $thumb[0];?>" alt="<?php the_title();?>" />
                     </div>
                     <div class="test-cmnt-text">
                        <h5><?php the_title();?></h5>
                        <h6><?php the_field('client_designation');?></h6>
                     </div>
                  </div>
                  <div class="tmo_icn"><i class="fa fa-comments" aria-hidden="true"></i></div>
               </div>
            <?php 
               endwhile;
               wp_reset_query();
            } // End If
            ?>

            </div>
         </div>
      </div>
   </section>

   <section class="subs_contact">
      <div class="container-wci">
         <div class="row">
            <div class="col-md-12">
               <div class="text-center cmn_hdr wow fadeInDown">
                  <h2><?php the_field('get_in_touch_title'); ?></h2>
                  <p><?php the_field('get_in_touch_content'); ?></p>
               </div>
               <div class="subs-form formsec">
                  <?php the_field('get_in_touch_form_section'); ?>
               </div>
            </div>
         </div>
      </div>
   </section>
<!--  end section  -->
<?php get_footer();  ?>  