<?php
/* Template Name: Contact Page Template */
get_header();
?>

<section class="inner_banner">
   <div class="bnr_hd">
      <h3><?php echo get_the_title(); ?></h3>
      <ul class="breadcrumb">
        <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
        <li><?php echo get_the_title(); ?></li>
      </ul>
   </div>
</section>

<?php while ( have_posts() ) : the_post();
the_content();
endwhile; ?>

<section class="contactmap_sec inner_cmn_mrgn">
   <div class="container-fluid">
      <div class="cmn_hdr text-left wow fadeInRight mrgn50">
         <h1>CONTACT DETAILS</h1>
      </div>
      <div class="contact_map">
         <div id="map"></div>
      </div>
      <div class="contact_info_bdy">
         <div class="contact_formsec">
            <div class="cmn_hdr text-left wow fadeInLeftBig mrgn30">
               <h3><?php the_field('contact_form_title'); ?></h3>
               <p><?php the_field('contact_form_text'); ?></p>
             </div>
             <div class="text-left formsec">
               <?php the_field('contact_form_shortcode'); ?>
            </div>
         </div>
         <div class="contact_dtlsse">
            <div class="cmn_hdr text-left wow fadeInLeftBig mrgn30">
               <h3>Contacts</h3>
               <p>Your email address will not be published. Required fields are marked *</p>
            </div>
            <div class="text-left forminfow">
               <ul>
                  <li class="d-flex">
                     <em><i class="fa fa-map-marker" aria-hidden="true"></i></em>
                     <?php the_field('address'); ?>
                  </li>
                  <li class="d-flex align-items-center">
                     <em><i class="fa fa-phone" aria-hidden="true"></i></em>
                     <a href="tel:<?php the_field('ddd'); ?>" class=""><?php the_field('phone'); ?></a>
                  </li>
                  <li class="d-flex align-items-center">
                     <em><i class="fa fa-envelope" aria-hidden="true"></i></em>
                     <a href="mailto:<?php the_field('ddd'); ?>" class=""><?php the_field('email'); ?></a>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</section>

<?php get_footer(); ?>