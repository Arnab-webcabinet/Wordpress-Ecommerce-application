<?php
/*Template Name: Common Template*/
get_header();
?>
<section class="inner_banner">
   <div class="bnr_hd">
      <h3><?php echo get_the_title(); ?></h3>
      <ul class="breadcrumb">
        <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
        <li><?php echo get_the_title(); ?></li>
      </ul>
   </div>
</section>
<!-- <section class="banner_sec inn-bn-s">
  <div class="bnr_sldr-inr-pg">
    <div class="bnr_otr">
      <div class="bnr_img_otr">
        <div class="bnr_pic zoom_otr">
          <img src="<?php //the_field('inner_banner_image'); ?>" class="zoom">
        </div>
      </div>
      <div class="bnr_content text-center">
        <div class="container-fluid">
          <div class="wow fadeInLeft">
            <h4><?php //the_field('inner_banner_title'); ?></h4>
            <h1><?php //the_field('inner_banner_main_title'); ?></h1>
          </div>
          <div class="wow fadeInRight" data-wow-delay="0.5s">
            <p><?php //the_field('inner_banner_content'); ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> -->
<!-- end banner -->
<section class="container-wci common-pdng">
      <?php
      while(have_posts()) {
        the_post();
        the_content();
      }
      ?>
</div>


<!--Contact section  -->
<?php //echo do_shortcode( '[contactsec_scode]' ); ?>

<?php get_footer();  ?>  