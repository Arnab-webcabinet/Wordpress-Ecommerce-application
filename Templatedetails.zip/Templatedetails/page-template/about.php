<?php
/* Template Name: About Page Template */
get_header();
?>
<section class="inner_banner">
   <div class="bnr_hd">
      <h3><?php echo get_the_title(); ?></h3>
      <ul class="breadcrumb">
        <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
        <li><?php echo get_the_title(); ?></li>
      </ul>
   </div>
</section>

<?php while ( have_posts() ) : the_post();
the_content();
endwhile; ?>
	   
<div id="exTab1" class="container">	
      <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Corporate Partners</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Community Partners</a>
			</li>
		</ul>

      <div class="tab-content clearfix">
         <div class="tab-pane active" id="1a">
            <div class="tab-content">
               <div class="prt-tab-in">
                  <div class="prt-tb-logo">
                     <img src="images/pr1.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr2.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr3.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr4.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr5.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr6.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr7.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr8.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr9.png" a;t="" />
                  </div>
                  <div class="prt-tb-logo">
                     <img src="images/pr10.png" a;t="" />
                  </div>
               </div>
            </div>
         </div>
         <div class="tab-pane" id="2a">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
         </div>
      </div>
  </div>

<?php get_footer(); ?>