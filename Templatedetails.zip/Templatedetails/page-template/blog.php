<?php
/* Template Name: Blog Page Template */
get_header();
?>

<section class="inner_banner">
   <div class="bnr_hd">
      <h3><?php echo get_the_title(); ?></h3>
      <ul class="breadcrumb">
        <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
        <li><?php echo get_the_title(); ?></li>
      </ul>
   </div>
</section>

<?php while ( have_posts() ) : the_post();
the_content();
endwhile; ?>

<section class="blog_sec inner_cmn_mrgn">
    <div class="container-fluid">
       <div class="blog_innr">
            <div class="row">
                <div class="col-md-9">
                  <div class="cmn_hdr text-left">
                  <h2>Latest Blog</h2>
                  <p>Read our latest blog to stay upadtated about ourselftt, and have better, healthy life ahed . Cras luctus feugiat interdum. Duis at quam ac nulla semper scelerisque sit amet id mi.</p>
               </div>
                    <div class="blog_box_otr">
                        <div class="row">
                          <div class="col-md-12">
                          <?php 
                          query_posts('post_type=post&post_status=publish&order=desc&posts_per_page=-1&paged='. get_query_var('paged'));
                          $i = 0.2; 
                          while( have_posts() ): the_post();
                          ?>
                            <div class="blog_box_innr pad_btm wow fadeInLeft" data-wow-delay="<?php echo $i=$i+0.2; ?>s">
                              <div class="blog_c">
                                
                                  <div class="blog_i">
                                    <a href="<?php echo get_permalink(); ?>">
                                      <?php if(has_post_thumbnail()) { 
                                        the_post_thumbnail();
                                      } else {
                                        echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/no_image.jpg" />';
                                      } ?>
                                    </a>
                                  </div>
                                  <a href="<?php echo get_permalink(); ?>">
                                  <h3><?php echo substr( get_the_title(), 0, 60); ?></h3>
                                </a>
                                  <ul class="dt_com">
                                    <li>
                                      <em><i class="fa fa-user-circle-o" aria-hidden="true"></i></em>
                                      <strong>By <?php the_author(); ?> </strong>
                                    </li>
                                    <li>
                                      <em><i class="fa fa-calendar" aria-hidden="true"></i></em>
                                      <strong><?php echo get_the_date( 'F j, Y' );?></strong></li>
                                  </ul>
                                  <p><?php echo substr( get_the_content(), 0, 400)."[...]"; ?></p>
                                  <a href="<?php echo get_permalink(); ?>" class="readmore_btn btn btn-primary">Read More</a>
                              </div>
                            </div>
                          <?php
                            endwhile;
                          ?>
                          </div>
                        </div>

                          <div class="shop_pgntn">
                            <!-- <div class="pgn_btn">
                              <a href="" class="btn">PREV</a>
                            </div>
                            <ul class="pagination">
                              <li class="active"><a href="#" class="page-link">1</a></li>
                              <li><a href="#" class="page-link">2</a></li>
                              <li><a href="#" class="page-link">3</a></li>
                              <li><a href="#" class="page-link">4</a></li>
                            </ul>
                            <div class="pgn_btn">
                              <a href="" class="btn">NEXT</a>
                            </div> -->
                            <?php 
                              global $wp_query; $big = 999999999; // need an unlikely integer
                              echo paginate_links( array(
                              'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                              'format' => '?paged=%#%',
                              'type'   => 'list',
                              'prev_text'    => __('<i class="fa fa-long-arrow-left" aria-hidden="true"></i>'),
                              'next_text'    => __('<i class="fa fa-long-arrow-right" aria-hidden="true"></i>'),
                              'current' => max( 1, get_query_var('paged') ),
                              'total' => $wp_query->max_num_pages
                              ) );  ?>  
                          </div>
                          <?php wp_reset_query(); ?>
                    </div>
                </div>
               <div class="col-md-3 wow fadeInRight">
                   <div class="blog_side">
                       <div class="hdr-btn">
                          <form method="get" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                            <input type="text" name="s" placeholder="Search..." required="required">
                            <button type="submit" value="Search" id="searchsubmit" class="submit"><i class="fa fa-search"></i></button>
                            <input type="hidden" name="post_type" value="post" />
                          </form>
                        </div>
                       
                        <div class="catagories blg_side_otr">
                          <h4>Catagories</h4>
                          <?php
                            $categories = get_categories( array(
                              'orderby' => 'name',
                              'parent'  => 0
                            ));
                          ?>
                          <ul class="latestblog_list">
                            <?php foreach ( $categories as $category ) { 
                            $category_id = get_cat_ID( $category->name );
                            // Get the URL of this category
                            $category_link = get_category_link( $category_id );
                            ?>
                            <li><a href="<?php echo esc_url( $category_link ); ?>"><?php echo $category->name; ?></a></li>
                            <?php } ?>
                          </ul>
                        </div>
                       
                        <div class="rec_post blg_side_otr">
                            <h4>LATEST BLOG</h4>
                            <div class="rec_pst_otr">
                            <?php 
                              $args = array(
                                'post_type'=> 'post',
                                'post_status' => 'publish',
                                'order'    => 'DESC',
                                'posts_per_page' => 5
                              );
                              $result1 = new WP_Query( $args );
                              if ( $result1-> have_posts() ) :
                              $i = 0;
                              while ( $result1->have_posts() ) : $result1->the_post();
                            ?>
                              <div class="rec_po_inr">
                                  <div class="bloglist_img">
                                    <?php if(has_post_thumbnail()) { 
                                      the_post_thumbnail();
                                    } else {
                                      echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/no_image.jpg" />';
                                    } ?>
                                  </div>
                                  <div class="post_con">
                                    <a href="<?php echo get_permalink(); ?>">
                                      <h5><?php echo substr( get_the_title(), 0, 15)."..."; ?></h5>
                                    </a>
                                    <p><?php echo substr( get_the_content(), 0, 45)."..."; ?></p>
                                  </div>
                              </div>
                            <?php
                              endwhile;
                              endif; 
                              wp_reset_postdata();  
                            ?>
                            <a href="<?php echo get_home_url(); ?>/blog" class="showmore_btn">Show More</a>
                            </div>
                       </div>
                   </div>
               </div>
           </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>