<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );
global $product;
/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
 * @hooked woocommerce_breadcrumb - 20
 * @hooked WC_Structured_Data::generate_website_data() - 30
 */
//do_action( 'woocommerce_before_main_content' );
?>
<section class="inner_banner">
   <div class="bnr_hd">
      <h3>SHOP</h3>
      <ul class="breadcrumb">
        <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
        <li>Shop</li>
      </ul>
   </div>
</section>

<section class="daily_ntrsec inner_cmn_mrgn">
	<div class="container-wci">
	<div class="row">
        <div class="col-md-9">
			<div class="cmn_hdr text-left wow fadeInDown">
				<h2>Latest Products</h2>
				<p>Most popular and valuabel product for you</p>
			</div>
			<div class="daily_ntrsec_bdy">
				<div class="row">
					<?php
					$args = array( 
					'post_type' => 'product', 
					// 'product_cat' => 'daily-nutrition',
					'posts_per_page' => -1, 
					'order' => 'DESC',    
					'orderby' => 'date'
					);     
					$loop = new WP_Query( $args );			
					if ( $loop->have_posts() ) 
					{  
					$i=0;
					while ( $loop->have_posts() ) : $loop->the_post(); 
					?>
					<div class="col-md-4 wow fadeInUp" data-wow-delay="0.<?php echo $i=$i+1; ?>s">
						<div class="sales_bx_innr">
							<div class="like_img"><?php echo do_shortcode( '[ti_wishlists_addtowishlist loop=yes]' ); ?></div>
							<div class="sales_prd">
								<img src="<?php the_post_thumbnail_url('full'); ?>" alt="<?php echo $post_id; ?>" />
							</div>
							<div class="sales_con">
								<h3><?php echo wp_trim_words( get_the_title(), 10, '...' ); ?></h3>
							</div>
							<div class="add_crt">
								<h4><del><?php echo get_woocommerce_currency_symbol(); ?> <?php echo $product->get_regular_price(); ?></del> – <?php echo get_woocommerce_currency_symbol(); ?> <?php echo $product->get_price(); ?></h4>
								<a href="<?php the_permalink(); ?>" class="cmn_btn btn btn-primary ">Add To Cart</a>
							</div>
						</div>
					</div>
					<?php endwhile; 
					} else { ?>
					<div class="text-center cmgsoon"><h4>Coming Soon..</h4></div>
					<?php }
					wp_reset_query();
					?>
				</div>
			</div>
		</div>
		<div class="col-md-3 wow fadeInRight">
            <div class="blog_side">
              <div class="hdr-btn">
                <!-- <form role="search" action="">
                  <input type="text" name="s" placeholder="Search..." required="">
                  <button type="submit" value="Search" id="searchsubmit" class="submit"><i class="fa fa-search"></i></button>
                </form> -->
                <form role="search" method="get" class="" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                     <input type="text" name="s" placeholder="Search..." required="required" value="<?php echo get_search_query(); ?>" >
                     <button type="submit" value="Search" id="searchsubmit" class="submit"><i class="fa fa-search"></i></button>
                     <input type="hidden" name="post_type" value="product" />
                </form>
              </div>
              
              <div class="catagories blg_side_otr">
                <h4>Catagories</h4>
                <ul class="latestblog_list">
                  <?php $orderby = 'name';
                      $order = 'asc';
                      $hide_empty = true ;
                      $cat_args = array(
                        'orderby'    => $orderby,
                        'order'      => $order,
                        'hide_empty' => $hide_empty,
                        'exclude'    => 16
                      );

                      $product_categories = get_terms( 'product_cat', $cat_args );
                      // print_r($product_categories);
                      global $wp_query;
                      //$current_category_name = $wp_query->query_vars['product_cat'];// Current Category
                      //echo $current_category_name;
                      $curTerm = $wp_query->queried_object;
                      if( !empty($product_categories) ){
                      //echo '<ul class="latestblog_list">';
                      foreach ($product_categories as $key => $category) {
                      // global $wp_query;
                      $cat_id   = $category->term_id;
                      $cat_link = get_category_link( $cat_id );

                      //$thumbnail_id = get_woocommerce_term_meta( $category->term_id, 'thumbnail_id', true ); // Get Category Thumbnail
                      //$image = wp_get_attachment_url( $thumbnail_id );
                      //$class = ( is_category( $current_category_name ) ) ? 'active' : '';

                      ?>
                      <?php
                      if ( $category->name == $curTerm->name ) {
                        $classes = 'active';
                      } else {
                        $classes = '';
                      }
                      ?>
                        <li class="<?= $classes ?>">
                          <?php echo '<a href="'.get_term_link($category).'">';
                          echo $category->name;
                          echo '</a>';
                          echo '</li>';
                          }
                          //echo '</ul>';
                      }
                  ?>
                </ul>
              </div>
              
              <div class="rec_post blg_side_otr">
                <h4>Top rated products</h4>
                <div class="product_rating_sec">
                  <ul class="list">
                    <?php
                    $args = array(
                    'post_type' => 'product',
                    'posts_per_page' => 12,
                    'tax_query' => array(
                    array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => 'featured',
                    ),
                    ),
                    );
                    $loop = new WP_Query( $args );
                    if ( $loop->have_posts() ) {
                    while ( $loop->have_posts() ) : $loop->the_post();
                    ?>
                    <li>
                      <div class="accr_img">
                        <div class="accr_img_inr"><img src="<?php the_post_thumbnail_url('full'); ?>" alt=""></div>
                      </div>
                      <div class="accr_det">
                        <h6><?php the_title(); ?></h6>
                        <div class="acc_rting leftslidrpro">
                          <!-- <img src="images/starrating_img.png" alt=""> -->
                          <?php
                          global $product;
                          echo wc_get_rating_html($product->get_average_rating());
                          ?>
                        </div>
                        <p>
                          <?php $review_count = $product->get_review_count();
                          if($review_count > 0):  ?>
                          <?php echo $review_count > 1 ? $review_count.' '.'REVIEWS' : $review_count.' '.'REVIEW' ?>
                          <?php else: ?>
                          No Reviews
                          <?php endif; ?>
                        </p>
                        <!-- <h3>$15.99 <strike>$23.99</strike></h3> -->
                        <h3 class="price"><?php //woocommerce_template_loop_price(); ?>
                        <?php
                        $product_type = $product->product_type;
                        if($product_type == 'variable') {
                        ?>
                        <?php echo $price_html = $product->get_price_html(); ?>
                        <?php } else { ?>
                        <?php echo get_woocommerce_currency_symbol().$product->get_sale_price(); ?>
                        <?php //echo get_woocommerce_currency_symbol().$product->get_regular_price(); ?>
                        <?php if($product->get_sale_price()) { ?>
                        <del><?php //echo get_woocommerce_currency_symbol().$product->get_sale_price(); ?>
                        <?php echo get_woocommerce_currency_symbol().$product->get_regular_price(); ?>
                        </del>
                        <?php } } ?>
                        </h3>
                      </div>
                    </li>
                    <?php
                    endwhile;
                    } else {
                    echo __( 'No products found' );
                    }
                    wp_reset_postdata();
                    ?>
                  </ul>
                  <a href="javascript:void();" class="showmore_btn" id="next">Show More</a>
                </div>
              </div>
            </div>
          </div>
	</div>
	</div>
</section>

<section class="sale_sec">
      <div class="container-wci">
         <div class="cmn_hdr text-center wow fadeInDown">
            <h2>Top Selling Product</h2>
            <p>Most popular and valuabel product for you</p>
         </div>
         <div class="sale_otr">
            <div id="home" class="tab-pane fade in active show">
               <div class="sales_innr slider_cmn_arw">
               <?php
			$tax_query[] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => 'featured',
				'operator' => 'IN', // or 'NOT IN' to exclude feature products
			);
			$args = array( 
			'post_type' => 'product', 
			// 'product_cat' => 'sports-nutrition',
			'posts_per_page' => -1, 
			'order' => 'DESC',    
			'orderby' => 'date',
			'tax_query' => $tax_query
			);     
			$loop = new WP_Query( $args );			
			if ( $loop->have_posts() ) 
			{   
			$i=0;
			while ( $loop->have_posts() ) : $loop->the_post(); 
			?> 
				<div class="sales_box">
					<div class="sales_bx_innr">
					<div class="like_img"><?php echo do_shortcode( '[ti_wishlists_addtowishlist loop=yes]' ); ?></div>
					<div class="sales_prd">
						<img src="<?php the_post_thumbnail_url('full'); ?>" alt="<?php echo $post_id; ?>" />
					</div>
					<div class="sales_con">
						<h3><?php echo wp_trim_words( get_the_title(), 10, '...' ); ?></h3>
					</div>
					<div class="add_crt">
						<h4><del><?php echo get_woocommerce_currency_symbol(); ?> <?php echo $product->get_regular_price(); ?></del> – <?php echo get_woocommerce_currency_symbol(); ?> <?php echo $product->get_price(); ?></h4>
						<a href="<?php the_permalink(); ?>" class="cmn_btn btn btn-primary ">Add To Cart</a>
					</div>
					</div>
				</div>
			<?php endwhile; 
			} else { ?>
			<div class="text-center cmgsoon"><h4>Coming Soon..</h4></div>
			<?php }
			wp_reset_query();
			?>
               </div>
            </div>
         </div>

      <?php //echo do_shortcode( '[azpswc_product_slider limit="8"]' ); ?>
      </div>
   </section>

<?php
/**
 * Hook: woocommerce_sidebar.
 *
 * @hooked woocommerce_get_sidebar - 10
 */
//do_action( 'woocommerce_sidebar' );

get_footer( 'shop' );