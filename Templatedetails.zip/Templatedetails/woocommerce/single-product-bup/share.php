<?php
/**
 * Single Product Share
 *
 * Sharing plugins can hook into here or you can add your own code directly.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/share.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

do_action( 'woocommerce_share' ); // Sharing plugins can hook into here.
/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
?>
<?php
    $url = get_permalink();
    $url = esc_url($url);
?>
<div class="pdtls_social_link follow-innr">
	<ul>
	<li><a href="http://www.facebook.com/sharer.php?u=<?php echo esc_url(get_permalink()); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
	<li><a href="https://twitter.com/sharer.php?u=<?php echo esc_url(get_permalink()); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
	<li><a href="https://www.instagram.com/sharer.php?u=<?php echo esc_url(get_permalink()); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
	</ul>
</div>


