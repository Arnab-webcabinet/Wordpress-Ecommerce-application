<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<?php //wc_product_class( '', $product ); ?>
<div <?php wc_product_class( 'item col-lg-4 col-md-6 mar-b', $product ); ?>>

    <div class="pr_otr">
        <div class="prd_ver_icn">
            <ul>
                <li><?php echo do_shortcode('[ti_wishlists_addtowishlist]'); ?></li>
                <!-- <li><a href="javascript:void(0);"><i class="fa fa-refresh" aria-hidden="true"></i></a></li> -->
                <?php $pro=$product->get_id();?>
                <li><?php //the_field('quick-view-shortcode',$pro ) ?><i class="fa fa-eye" aria-hidden="true"></i></li>
            </ul>
        </div>
        <div class="pr_img">
            <div class="pr_img_inr">
                <a href="<?php the_permalink(); ?>" target="_blank">
                    <img src="<?php echo wp_get_attachment_url( $product->get_image_id(),  'full'  ); ?>" />
                </a>
            </div>
        </div>
        <div class="prd_det text-center">
            <div class="shp_det">
                <h4><?php echo $product->get_title(); ?></h4>
                <ul>
                    <li>
<!--                        <img src="--><?php //bloginfo('template_url'); ?><!--/images/prd_rting.png" alt="">-->
                        <?php woocommerce_template_loop_rating(); ?>
                    </li>
                    <li>
                      <?php $review_count = $product->get_review_count();
                      if($review_count > 0):  ?>
                          <h5><?php echo $review_count > 1 ? $review_count.' '.'REVIEWS' : $review_count.' '.'REVIEW' ?></h5>
                      <?php else: ?>
                          <h5>No Reviews</h5>
                      <?php endif; ?>
                    </li>
                </ul>
            </div>
            <div class="shp_by">
                <h3><?php woocommerce_template_loop_price(); ?></h3>
                <div class="shop_btn">
                    <?php
                        $product_type = $product->product_type;
                        if($product_type == 'variable') {
                    ?>
<!--                          --><?php //do_action( 'woocommerce_after_shop_loop_item' ); ?>
                        <a href="<?php echo get_the_permalink(); ?>" class="btn"><em><i class="fas fa-shopping-cart"></i></em>SELECT OPTIONS</a>
                    <?php } else { ?>
                    <?php woocommerce_template_loop_add_to_cart(); ?>
                    <?php } ?>
<!--                    <a href="javascript:void(0);" class="btn"><em><i class="fas fa-shopping-cart"></i></em>SELECT OPTIONS</a>-->
                </div>
            </div>
        </div>
    </div>
	<?php
	/**
	 * Hook: woocommerce_before_shop_loop_item.
	 *
	 * @hooked woocommerce_template_loop_product_link_open - 10
	 */
	//do_action( 'woocommerce_before_shop_loop_item' );

	/**
	 * Hook: woocommerce_before_shop_loop_item_title.
	 *
	 * @hooked woocommerce_show_product_loop_sale_flash - 10
	 * @hooked woocommerce_template_loop_product_thumbnail - 10
	 */
	//do_action( 'woocommerce_before_shop_loop_item_title' );

	/**
	 * Hook: woocommerce_shop_loop_item_title.
	 *
	 * @hooked woocommerce_template_loop_product_title - 10
	 */
	//do_action( 'woocommerce_shop_loop_item_title' );

	/**
	 * Hook: woocommerce_after_shop_loop_item_title.
	 *
	 * @hooked woocommerce_template_loop_rating - 5
	 * @hooked woocommerce_template_loop_price - 10
	 */
	//do_action( 'woocommerce_after_shop_loop_item_title' );

	/**
	 * Hook: woocommerce_after_shop_loop_item.
	 *
	 * @hooked woocommerce_template_loop_product_link_close - 5
	 * @hooked woocommerce_template_loop_add_to_cart - 10
	 */
	//do_action( 'woocommerce_after_shop_loop_item' );
	?>
</div>
<!--</li>-->
